#ifndef QUEUE_H
#define QUEUE_H
#include <exception>
#include <stdexcept>

// Definicao do struct Node
struct Node {
    int key;       // guarda inteiro (chave)
    Node *next;    // ponteiro para proximo no
};

class Queue {
private:
    Node* head; // ponteiro para o primeiro no
    Node* tail;  // ponteiro para o ultimo no

public:
    Queue() {
        head = tail = nullptr;
    }

    ~Queue() {
        while(head != nullptr) {
            Node *aux = head;
            head = head->next;
            delete aux;
        }
        tail = nullptr;
    }

    bool empty() {
        return head == nullptr;
    }

    void enqueue(int key) {
        Node *novo = new Node;
        novo->key = key;
        novo->next = nullptr;

        // Fila vazia
        if(head == nullptr) 
            head = tail = novo;
        else {
            tail->next = novo;
            tail = novo;
        }
    }

    void dequeue() {
        if(head == nullptr)
            throw std::runtime_error("Fila vazia. Nao eh possivel desenfileirar");
        Node *aux = head;
        head = head->next;
        delete aux;
        if(head == nullptr) 
            tail = nullptr;
    }

    int getHead() {
        if(head == nullptr)
            throw std::runtime_error("Fila vazia. Nao existe elemento");
        return head->key;
    }

    int getTail() {
        if(tail == nullptr)
            throw std::runtime_error("Fila vazia. Nao existe elemento");
        return tail->key;
    }
};

#endif
