#include <iostream>
#include <stdexcept> // biblioteca para tratamento de excecao
#include "Queue.h"  // inclui biblioteca da fila
using namespace std;

int main() {
    
    Queue fila;

    for(int i = 1; i <= 10; i++)
        fila.enqueue(i);

    try {

        for(int i = 1; i <= 15; i++) {
            cout << fila.getHead() << endl;
            fila.dequeue();
        }

    }
    catch(std::runtime_error e) {
        cerr << "Erro: " << e.what() << endl;
    }

    
    

    return 0;
}
