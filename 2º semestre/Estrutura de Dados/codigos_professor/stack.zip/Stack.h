#ifndef STACK_H
#define STACK_H
#include <iostream>
#include <cassert>
#include "Item.h"

class Stack {
    private: 
        Item *_vec; // Ponteiro para um vetor de Item
        int _top; // Posicao do proximo slot disponivel
        int _capacity; // Tamanho total do vetor
    public: 
        // Construtor: recebe capacidade
        Stack(int n) {
            _vec = new Item[n];
            _capacity = n;
            _top = 0;
        }

        // Destrutor: libera memoria alocada
        ~Stack() {
            if(_vec != nullptr) 
                delete[] _vec;
        }

        // Inserir elemento no topo
        void push(Item v) {
            if(_top != _capacity) {
                _vec[_top] = v;
                _top++;
            }
        }

        // Remover elemento do topo
        void pop() {
            if(_top != 0) {
                _top--;
            }   
        }

        // Consulta elemento no topo
        Item top() { 
            assert(_top != 0);
            return _vec[_top-1];
        }

        // Pilha esta vazia?
        bool empty() {
            return _top == 0;
        }

        // Pilha esta cheia?
        bool full() {
            return _top == _capacity;
        }
};

#endif
