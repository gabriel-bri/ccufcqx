/**
 * Define um tipo chamado Item
 */
#ifndef ITEM_STACK_H
#define ITEM_STACK_H

typedef double Item;  

#endif 
