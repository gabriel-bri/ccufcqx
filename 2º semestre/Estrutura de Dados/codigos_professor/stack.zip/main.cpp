#include <iostream>
#include "Item.h"
#include "Stack.h"

using namespace std;

int main()
{
	Stack p(20);

	for(int i = 1; i <= 10; i++) {
		p.push(i);
	}
	
	while(!p.empty()) {
		cout << p.top() << endl;
		p.pop();
	}

	return 0;
}