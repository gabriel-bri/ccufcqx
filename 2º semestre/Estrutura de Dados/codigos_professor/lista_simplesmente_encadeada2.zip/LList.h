#ifndef LLIST_H
#define LLIST_H
#include <iostream>
#include <cassert>

struct Node {
    int key;
    Node *next;

    // Construtor do struct Node
    // Obs.: Em C++ os structs tambem podem ter construtores,
    // destrutores ou quaisquer outras funcoes que voce quiser. 
    Node(const int& k, Node *nextval) { 
        key = k;
        next = nextval;
    }
};

class LList {
private:
    Node *head;     // Ponteiro para a cabeca da lista
    Node *tail;     // Ponteiro para o ultimo elemento da lista
    Node *atual;    // Ponteiro para o elemento atual
    int size;       // Tamanho da lista

    // Funcao auxiliar de inicializacao dos 
    // atributos privados
    void init() {
        tail = atual = head = new Node(0, nullptr);
        size = 0;
    }

    // Libera todos os nos alocados, inclusive o no cabeca
    void removeAll() {
        while(head != nullptr) {
            Node *aux = head;
            head = head->next;
            delete aux;
        }
        tail = atual = nullptr;
    }
    
public:
    // Construtor
    LList() {
        init();
    } 
    
    // Destrutor
    ~LList() {
        removeAll();
    }

    // Deixa a lista vazia, com zero elementos
    void clear() {
        removeAll();
        init();
    }

    // Insere um elemento na posicao atual
    // item: o elemento a ser inserido
    void insert(const int& item) {
        Node *p = new Node(item, atual->next);
        atual->next = p;
        if(atual == tail) 
            tail = tail->next;
        size++;
    }

    // adiciona um elemento ao final da lista
    // item: o elemento a ser inserido
    void append(const int& item) {
        Node *p = new Node(item, nullptr);
        tail = tail->next = p;
        size++;
    }

    // Remove o elemento atual e devolve o seu valor
    int remove() {
        assert(atual != tail);
        int valor = atual->next->key;
        Node *rem = atual->next;
        atual->next = atual->next->next;
        delete rem;
        size--;
        return valor;
    }

    // Remove sempre o ultimo elemento da lista 
    // e devolve o seu valor
    // Se nao houver elemento, o programa deve abortar
    // Apos essa operacao, o ponteiro 'atual' pode acabar
    // apontando para qualquer posicao valida da lista 
    int remove_back() {
        assert(tail != head);
        for(atual = head; atual->next != tail; atual = atual->next);
        int valor = tail->key;
        delete tail;
        tail = atual;
        tail->next = nullptr;
        size--;
        return valor; 
    }

    // Configura a posicao atual para o inicio da lista
    void moveToStart() {
        atual = head;
    }

    // Configura a posicao atual para o final da lista
    void moveToEnd() {
        atual = tail;
    }

    // Move a posicao atual uma posicao para tras.
    // Nada acontece se a posicao ja estiver no inicio da lista
    void prev() {
        if(atual == head) return;
        Node *aux = head;
        while(aux->next != atual)
            aux = aux->next;
        atual = aux;
    }

    // Move a posicao atual uma posicao a frente.
    // Nada acontece se a posicao ja estiver no final da lista
    void next() {
        if(atual == tail) return;
        atual = atual->next;
    }

    // Devolve o numero de elementos da lista
    int length() const {
        return size;
    }

    // Devolve a posicao do elemento atual
    // Lembre que na nossa lista os elementos sao indexados
    // com os inteiros de 0 a n-1
    int posAtual() const {
        int i = 0;
        Node *aux = head;
        while(aux != atual) {
            aux = aux->next;
            i++;
        }
        return i;
    }

    // Configura a posicao atual
    // O ponteiro 'atual' passa a apontar para o node na posicao 'newpos'
    void moveToPos(int newpos) {
        assert(newpos >= 0 && newpos <= size);
        Node *aux = head;
        for(int i = 0; i < newpos; i++) {
            aux = aux->next;
        }
        atual = aux;
    }

    // Devolve o valor do elemento atual
    int& getValue() const {
        assert(atual != tail);
        return atual->next->key;
    }

    // Devolve 'true' se a lista estiver vazia e 'false' caso contrario
    bool empty() const {
        return head == tail;
    }

    // operador[] sobrecarregado
    // Devolve uma referencia para o elemento na posicao 'index' da lista
    // Esta funcao tem complexidade O(n) no pior caso
    int& operator[](const int& index) {
        assert(index >= 0 && index < size);
        int pos = 0;
        Node *aux = head->next;
        while(pos < index) {
            aux = aux->next;
            pos++;
        }
        return aux->key;
    }

    bool inTheEnd() {
        return atual == tail;
    }

    // remove da lista todas as ocorrencias do inteiro x
    // Esta funcao deve ter complexidade O(n) no pior caso
    // Obs.: Apos a execucao dessa funcao, o ponteiro 'atual' pode terminar
    // apontando para qualquer node da lista resultante.
    void removeAll(const int& x);

    // Devolve um ponteiro para uma copia desta lista
    // Esta funcao deve ter complexidade O(n) no pior caso
    LList *copy();

    // Copia os elementos do array v[0..n-1] para o final da lista. 
    // Esta funcao deve ter complexidade O(n) no pior caso
    void appendArray(int v[], int n);

    // Determina se a lista lst, passada por parametro, eh igual 
    // a lista em questao. Duas listas sao iguais se elas tem o mesmo tamanho 
    // e o valor do k-esimo elemento da primeira lista eh igual ao k-esimo valor da segunda lista.
    bool equal(const LList& lst);

    // Inverte a ordem dos nos (o primeiro no passa a ser o ultimo, 
    // o segundo passa a ser o penultimo, etc.) 
    // Restricao: Essa operacao faz isso sem criar novos nodes, apenas altera os ponteiros.
    // Voce pode criar ponteiros auxiliares, mas nao pode alocar novos nodes.
    void reverse();
};

#endif
