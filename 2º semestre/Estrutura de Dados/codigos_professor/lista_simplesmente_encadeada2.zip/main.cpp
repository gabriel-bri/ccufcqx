#include <iostream>
#include "LList.h"
using namespace std;

int main()
{
	LList lst; // Cria lista vazia

	// Insere os inteiros de 1 a 20 na lista
	for(int i = 0; i < 35; i++)
		lst.append(i+1);

	// Imprime todos os elementos da lista na tela
	// Percorre lista em O(n^2)
	for(int i = 0; i < lst.length(); i++)
		cout << lst[i] << " "; // Aqui, estou usando o operador[] que foi sobrecarregado
	
	cout << endl;

	for(lst.moveToStart(); !lst.inTheEnd(); lst.next()) // Percorre lista em O(n)
		cout << lst.getValue() << " ";

	cout << endl;

	return 0;
}