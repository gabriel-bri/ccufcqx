#include <iostream>
#include "Tree.h"
using namespace std;

int main()
{
	Tree arv; // Cria arvore vazia (igual a nullptr)

	arv.insert(33, -1, '0'); // 33 eh a raiz da arvore
	arv.insert(22, 33, LEFT);
	arv.insert(87, 22, RIGHT);
	arv.insert(99, 33, RIGHT);
	arv.insert(7, 99, RIGHT);
	arv.insert(8, 99, LEFT);
	arv.insert(6, 8, LEFT);
	arv.insert(5, 8, RIGHT);
	arv.insert(1, 6, LEFT);
	arv.insert(10, 1, RIGHT);
	arv.insert(666, 8, RIGHT); // essa chave nao deve ser inserida pois 8 ja tem dois filhos

	arv.print(); // imprime todas as chaves

	cout << endl;

	return 0;
}