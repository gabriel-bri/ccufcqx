#ifndef TREE_H
#define TREE_H
#include <iostream>
#define LEFT 'l'
#define RIGHT 'r'

struct Node {
    int key;
    Node *left;
    Node *right;

    Node(int k, Node *l = nullptr, Node *r = nullptr) {
        key = k;
        left = l;
        right = r;
    }

    ~Node() {
        std::cout << "Removido: " << key << std::endl;
    }
};

class Tree {
private:
    Node *root;
    void print(Node *node);
    Node *clear(Node *node); 
    Node *insert(Node *node, int key, int parent, char position);
public:
    Tree();
    ~Tree();
    bool empty();
    bool contains(int k);
    void print(); // Imprime todas as chaves da arvore
    void clear();
    void insert(int key, int parent, char position); // estou supondo que as chaves sao todas distintas
};

Tree::Tree() {
    root = nullptr;
}

Tree::~Tree() {
    root = clear(root);
}

bool Tree::empty() {
    return root == nullptr;
}

// Imprime todas as chaves da arvore
void Tree::print() {
    print(root);
}

// Funcao recursiva
// Recebe como parametro um node e 
// imprime na tela todas as chaves da subarvore enraizada nesse node
void Tree::print(Node *node) {
    /*
    if(node == nullptr) // Caso Base ou Caso de Parada
        return;
    else { // Caso geral ou Caso recursivo
        std::cout << node->key << " ";
        print(node->left); // imprime todas as chaves a esquerda
        print(node->right); // imprime todas as chaves a direita
    }
    */

    if(node != nullptr) {
        std::cout << node->key << " ";
        print(node->left); // imprime todas as chaves a esquerda
        print(node->right); // imprime todas as chaves a direita
    }
}

// Funcao publica
// Deixa a arvore vazia
void Tree::clear() {
    root = clear(root);
}

// Funcao privada
// Recebe como argumento um ponteiro para a raiz de uma subarvore
// e deleta (libera) todos os nos alocados que estao nessa subarvore
Node *Tree::clear(Node *node) {
    /*
    if(node == nullptr) // Caso de parada: arvore vazia
        return nullptr;
    else { // Caso geral
        node->left = clear(node->left);
        node->right = clear(node->right);
        delete node;
        return nullptr;
    }
    */

    if(node != nullptr) {
        node->left = clear(node->left);
        node->right = clear(node->right);
        delete node;
    }
    return nullptr; // Caso de parada
}

// Funcao publica
void Tree::insert(int key, int parent, char position) {
    root = insert(root, key, parent, position);
}

// Funcao privada
// Recebe como argumento um ponteiro para a raiz de uma subarvore,
// a chave a ser inserida, a chave do pai e a posicao (left ou direita)
// Supomos que as chaves entradas sao todas distintas.
// A chave eh inserida na posicao somente se nao houver chave la.
Node *Tree::insert(Node *node, int key, int parent, char position) {
    if(node == nullptr) { // Caso Base 1: arvore vazia
        Node *novo = new Node(key);
        return novo;
    }
    if(node->key == parent) { // Caso Base 2: Achei o pai uhuhuhu
        if(position == LEFT && node->left == nullptr) {
            node->left = insert(node->left, key, parent, position);
            return node;
        }
        else if(position == RIGHT && node->right == nullptr) {
            node->right = insert(node->right, key, parent, position);
            return node;
        }
        else return node;
    }
    if(node->left != nullptr)  // Caso geral: nao estou no pai e posso ir para a esquerda
         node->left = insert(node->left, key, parent, position);
    if(node->right != nullptr)  // Caso geral: nao estou no pai e posso ir para a direita
        node->right = insert(node->right, key, parent, position);
    return node;
}

#endif