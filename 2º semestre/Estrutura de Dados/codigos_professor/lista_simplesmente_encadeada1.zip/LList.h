#ifndef LLIST_H
#define LLIST_H
#include <iostream>
#include <cassert>

struct Node {
    int key;
    Node *next;

    // Construtor do struct Node
    // Obs.: Em C++ os structs tambem podem ter construtores,
    // destrutores ou quaisquer outras funcoes que voce quiser. 
    Node(const int& k, Node *nextval) { 
        key = k;
        next = nextval;
    }
};

class LList {
private:
    Node *head;     // Ponteiro para a cabeca da lista
    Node *tail;     // Ponteiro para o ultimo elemento da lista
    Node *atual;    // Ponteiro para o elemento atual
    int size;       // Tamanho da lista

    // Funcao auxiliar de inicializacao dos 
    // atributos privados
    void init() {
        tail = atual = head = new Node(0, nullptr);
        size = 0;
    }

    // Libera todos os nos alocados, inclusive o no cabeca
    void removeAll() {
        while(head != nullptr) {
            Node *aux = head;
            head = head->next;
            delete aux;
        }
        tail = atual = nullptr;
    }
    
public:
    // Construtor
    LList() {
        init();
    } 
    
    // Destrutor
    ~LList() {
        removeAll();
    }

    // Deixa a lista vazia, com zero elementos
    void clear() {
        removeAll();
        init();
    }

    // Insere um elemento na posicao atual
    // item: o elemento a ser inserido
    void insert(const int& item) {
        Node *p = new Node(item, atual->next);
        atual->next = p;
        if(atual == tail) 
            tail = tail->next;
        size++;
    }

    // adiciona um elemento ao final da lista
    // item: o elemento a ser inserido
    void append(const int& item) {
        Node *p = new Node(item, nullptr);
        tail = tail->next = p;
        size++;
    }

    // Remove o elemento atual e devolve o seu valor
    int remove();

    // Remove sempre o ultimo elemento da lista 
    // e devolve o seu valor
    int remove_back();

    // Configura a posicao atual para o inicio da lista
    void moveToStart();

    // Configura a posicao atual para o final da lista
    void moveToEnd();

    // Move a posicao atual uma posicao para tras.
    // Nada acontece se a posicao ja estiver no inicio da lista
    void prev();

    // Move a posicao atual uma posicao a frente.
    // Nada acontece se a posicao ja estiver no final da lista
    void next();

    // Devolve o numero de elementos da lista
    int length() const;

    // Devolve a posicao do elemento atual
    int posAtual() const;

    // Configura a posicao atual
    void moveToPos(int newpos);

    // Devolve o elemento atual
    int& getValue() const;

    // Devolve true se lista vazia e false caso contrario
    bool empty() const;

    // operador[] sobrecarregado
    // devolve uma referencia para o elemento na posicao i da lista
    int& operator[](const int& index) {
        assert(index >= 0 && index < size);
        int pos = 0;
        Node *aux = head->next;
        while(pos < index) {
            aux = aux->next;
            pos++;
        }
        return aux->key;
    }
};

#endif
