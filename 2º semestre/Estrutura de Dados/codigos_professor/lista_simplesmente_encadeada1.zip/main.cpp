#include <iostream>
#include "LList.h"
using namespace std;

int main()
{
	LList lst; // Cria lista vazia

	// Insere os inteiros de 1 a 20 na lista
	for(int i = 0; i < 20; i++)
		lst.append(i+1);

	// Imprime todos os elementos da lista na tela
	for(int i = 0; i < 20; i++)
		cout << lst[i] << " "; // Aqui, estou usando o operador[] que foi sobrecarregado
	
	cout << endl;

	return 0;
}