para compilar usando o terminal, entre nesta pasta e digite:


make


ou, se preferir, digite o comando:



g++ -o main main.cpp Point.cpp && ./main
