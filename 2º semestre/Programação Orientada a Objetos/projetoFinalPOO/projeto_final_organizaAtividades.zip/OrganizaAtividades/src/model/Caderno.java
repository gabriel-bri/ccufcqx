package model;

public abstract class Caderno {
	
}
