

#include "replacement.h"


int runNRU(int page)
{
  PRINT_FUNCTION();

  return -1;
}

int runFIFO(int page)
{
  PRINT_FUNCTION();

  return -1;
}


int runSecondChance(int page)
{
  PRINT_FUNCTION();

  return -1;
}

int runClock(int page)
{
  PRINT_FUNCTION();

  return -1;
}

int runLFU(int page)
{
  PRINT_FUNCTION();

  return -1;
}

int runNFU(int page)
{
  PRINT_FUNCTION();

  return -1;
}


int replacePage(int page, ReplacementAlgo algo, PageEntry *pt)
{
  switch(algo)
  {
    case NRU:
     return runNRU(page);//
    break;
    case FIFO:
     runFIFO(page);
    break;
    case SECOND_CHANCE:
     runSecondChance(page);
    break;
    case CLOCK:
     runClock(page);//
    break;
    case LFU:
     runLFU(page);
    break;
    case NFU:
     runNFU(page);//
    break;
    
    default:
     return -1;
    break;
   
  }

  return -1;
 
}






