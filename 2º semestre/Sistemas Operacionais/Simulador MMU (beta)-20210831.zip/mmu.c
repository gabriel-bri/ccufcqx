#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>
#include <semaphore.h>

#include "mmu.h"
#include "utils.h"
#include "replacement.h"

sem_t mutex;
PageEntry page_table[N_PAGES];


pthread_t mmu_thread;

int pipe_to_mmu[2], pipe_from_mmu[2];


void printPageTable(PageEntry *pt)
{
  printf("|----------------------------------------------------------------------------|\n");
  printf("| Page | Frame | P | R | M | Virt. Start | Virt. End | Real Start | Real End |\n");
  printf("|----------------------------------------------------------------------------|\n");

  for (int i=0;i<N_PAGES;i++)
  {
    if(pt[i].present)
    {
      changeTerminalColor(GREEN);
    }
    else
    {
      changeTerminalColor(RED);
    }
    printf("|%6d|%7d|%3d|%3d|%3d|%13d|%11d|%12d|%10d|\n",
           i,
           pt[i].frame,
           pt[i].present,
           pt[i].R,
           pt[i].M,
           i*PAGE_SIZE,
           i*PAGE_SIZE + PAGE_SIZE-1,
           (pt[i].frame*PAGE_SIZE)*pt[i].present,
           (pt[i].frame*PAGE_SIZE + PAGE_SIZE-1)*pt[i].present);
    changeTerminalColor(DEFAULT);
  }
  printf("|----------------------------------------------------------------------------|\n");

}


void pageTableInit(PageEntry *pt)
{
  memset(pt, 0, sizeof(PageEntry)*N_PAGES);


  int frame = 0;
  do 
  {
    
    int page = getRandom(N_PAGES);
    if (pt[page].present == 0)
    {
       pt[page].present = 1;
       pt[page].frame = frame++;
       pt[page].R = getRandom(2);
       pt[page].M = getRandom(2);
    }
  }while (frame < N_FRAMES);

}


int pageFaultHandler(int page)
{
    printf("Page Fault!!!\n");

    return replacePage(page, NRU, page_table);
}


void *mmu(void* args)
{

  int r_addr = 0;
  int frame = 0;
 
  while(1)
  {
    int ret=0; 

    //lê pipe
    MemAccess ma;
    printf("MMU aguardando endereço\n");
    while(read(pipe_to_mmu[RD], &ma, sizeof(MemAccess))!=sizeof(MemAccess)); 

    printf("MMU recebeu o endereço 0x%X\n",ma.addr);
 
    
    int page = ma.addr >> PAGE_SIZE_BITS; 
    int offset = ma.addr & (PAGE_SIZE-1);  

    printf("Page: %d, Offset: 0x%X\n",page, offset);
  
    //trata page fault  
    if(page_table[page].present == 0)
    {
      ret = pageFaultHandler(page);
    }

    if (ret == -1)
    {
      printf("Page Fault Handling Error!!!\n");
      r_addr = ma.addr; 
    }
    else
    {
      frame = page_table[page].frame;
      r_addr = frame*PAGE_SIZE + offset;
      page_table[page].R  = 1;
      page_table[page].M |= ma.rw; //0 é leitura e 1 é escrita;
    }

    //retorna o endereco real
    write(pipe_from_mmu[WR], &r_addr, sizeof(int)); 
    
  }
}

int Init(void)
{
  srand(time(NULL));

  sem_init(&mutex, 0, 1);

  //cria pipes
  if(pipe(pipe_to_mmu)<0)
  {
    perror("pipe") ;
    return -1 ;
  }
  if(pipe(pipe_from_mmu)<0)
  {
    return -1 ;
  }

  //cria thread da mmu
  if (pthread_create(&mmu_thread, NULL, mmu, NULL) != 0)
  {
    printf("Erro ao criar thread %s\n", strerror(errno));
    return -1;
  }

  return 0;
}

int main(void)
{
  if(Init())
  {
     printf("Erro na inicialização!\n");
  
     exit(0);
  }
  
  printf("\nReal Memory   : 0x%04X to 0x%04X \n", REAL_MEMORY_START,REAL_MEMORY_END);
  printf("Virtual Memory: 0x%04X to 0x%04X \n\n", VIRTUAL_MEMORY_START,VIRTUAL_MEMORY_END);

  pageTableInit(page_table);
  
  //tabela antes do acesso
  printPageTable(page_table);
  
  int virtual = 0xFBCD;
  int real = 0;//mmu(virtual,0);

  MemAccess ma;
  
  while(1)
  {
    printf("Insira o endereco virtual: \n");
    scanf("%d", &virtual);

    if(virtual > (VIRTUAL_MEMORY_END) || virtual < (VIRTUAL_MEMORY_START))
    {
       printf("Endereço inválido!!\n");

       pthread_cancel(mmu_thread);
       pthread_join(mmu_thread,0);
      
       close(pipe_from_mmu[0]);
       close(pipe_from_mmu[1]);
       close(pipe_to_mmu[0]);
       close(pipe_to_mmu[1]);
       exit(0);
    }   

    ma.addr = virtual;
    ma.rw = 0;
    write(pipe_to_mmu[WR], &ma, sizeof(MemAccess));

    while(read(pipe_from_mmu[RD], &real, sizeof(real))!=sizeof(real));

    printf("Virtual: 0x%04X -> Real: 0x%04X\n",virtual, real);
  
    //tabela depois do acesso
    printPageTable(page_table);
  }
  
  return 0;
}




