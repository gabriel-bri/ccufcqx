#ifndef _REPLACEMENT_H_
#define _REPLACEMENT_H_

#include "mmu.h"
#include "utils.h"


typedef enum _REPLACEMENT_ALGORITHMS_
{
  NRU,
  FIFO,
  SECOND_CHANCE,
  CLOCK,
  LFU,
  NFU,
  WSCLOCK
}ReplacementAlgo;

extern int replacePage(int page, ReplacementAlgo algo,  PageEntry *pt);


#endif
