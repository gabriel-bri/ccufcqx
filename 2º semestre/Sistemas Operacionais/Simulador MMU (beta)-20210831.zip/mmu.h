#ifndef _MMU_H_
#define _MMU_H_


#define PAGE_SIZE_BITS 12
#define PAGE_SIZE (1<<PAGE_SIZE_BITS)
#define N_PAGES        16
#define N_FRAMES        8


#define REAL_MEMORY_START 0x0
#define REAL_MEMORY_END   (REAL_MEMORY_START + (PAGE_SIZE*N_FRAMES)-1)


#define VIRTUAL_MEMORY_START 0x0
#define VIRTUAL_MEMORY_END   (VIRTUAL_MEMORY_START + (PAGE_SIZE*N_PAGES)-1)




typedef struct _PAGE_ENTRY_
{
  int frame;
  int R;
  int M;
  int present;
  int cache;
  int protection;
}PageEntry;

typedef struct _MEM_ACCESS_
{
  #define WR 1
  #define RD 0
  
  int addr;
  int rw;
}MemAccess;








#endif
