#ifndef _UTILS_H_
#define _UTILS_H_
#include <stdio.h>

#define PRINT_FUNCTION(...) printf("Running function: %s in file %s:%d\n", __func__,__FILE__, __LINE__)

typedef enum 
{
  DEFAULT,
  RED,
  GREEN,
  BLUE,
  YELLOW
}Color;

extern int getRandom(int max);
extern void changeTerminalColor(Color c);


/* Define as funções down e up como sem_wait e sem_post*/
#define down sem_wait
#define up sem_post





#endif

