#include <stdlib.h>
#include <stdio.h>
#include "utils.h"


int getRandom(int max)
{
  return rand() % max;
}
 
void changeTerminalColor(Color c)
{
  switch (c)
  {
    case RED:
     printf("\033[1;31m");
    break;
    case GREEN:
     printf("\033[1;32m");
    break;
    case YELLOW:
     printf("\033[1;33m");
    break;
    case BLUE:
     printf("\033[0;34m");
    break;

    default:
     printf("\033[0m"); //default color
    break;
  }
  
}

