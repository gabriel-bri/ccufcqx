#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <errno.h>
#include <string.h>



void child(void)
{
  //inicia valores
  pid_t my_pid = getpid(); 
  int my_prio = getpriority(PRIO_PROCESS, my_pid);
  int my_new_prio = my_prio;

  printf("(child) Process: %d, prioridade inicial: %d\n",my_pid, my_prio);

  while(1)
  {
    //ler prioridade atual/nova
    my_new_prio = getpriority(PRIO_PROCESS, my_pid);
   
    //verificar se prioridade mudou
    if(my_new_prio != my_prio)
    {
      //atualizar prioridade
      my_prio = my_new_prio;
    
      //escreve uma msg
      printf("(child) Process: %d, mudou a prioridade para : %d\n",my_pid, my_prio);
     
      //encerra se prioridade for == -15
      if(my_prio == -15)
      {
         printf("(child) Encerrando processo %d\n",my_pid);
        return;
      }     
    }
  } 
}


void parent(pid_t child_pid)
{
  //inicia valores
  pid_t my_pid = getpid(); 
  int my_prio = getpriority(PRIO_PROCESS, my_pid);
  int my_new_prio = my_prio;

  printf("(parent) Process: %d, prioridade inicial: %d\n",my_pid, my_prio);

  while(1)
  {
    //ler prioridade atual/nova
    my_new_prio = getpriority(PRIO_PROCESS, my_pid);
   
    //verificar se prioridade mudou
    if(my_new_prio != my_prio)
    {
      //atualizar prioridade
      my_prio = my_new_prio;
      
      //muda a prioridade do filho
     
      if(setpriority(PRIO_PROCESS, child_pid, my_prio+1)==-1)
      {
        printf("(parent) Process: %d, ERRO ao alterar prioridade do processo %d\n",my_pid, child_pid);
        printf("ERRO: %s\n", strerror(errno));
      }   
      
      //escreve uma msg
      printf("(parent) Process: %d, mudou a prioridade para : %d\n",my_pid, my_prio);
     
      //encerra se prioridade for == -15
      if(my_prio == -15)
      {
        printf("(parent) Encerrando processo %d\n",my_pid);
        return;
      }     
    }
  } 
}



int main(void)
{
  pid_t ch_pid = fork();

  if(ch_pid < 0)
  {
    //erro
    return -1;
  } 
  else if(ch_pid == 0)
  {
   //child
   child();
  }
  else
  {
    //pai
    parent(ch_pid);
  }


}



