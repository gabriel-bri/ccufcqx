//gcc -lpthread -lrt

/*
ls -l /dev/shm 
cat /proc/<pid>/maps
cat /proc/<pid>/smaps 
pmap -x <pid>
*/


#include "shared.h"


/* Ponteiros para os semaforos */
sem_t *sem_empty;
sem_t *sem_full;
sem_t *mutex;

/* Ponteiro para o buffer compartilhado */
SharedBuffer *shared_buffer = 0;


int main(void)
{
    // Aloca os semáforos 
    init_semaforo(&sem_empty,SEMPHR_EMPTY_PATH,1); 
    init_semaforo(&sem_full,SEMPHR_FULL_PATH,0);
    init_semaforo(&mutex,SEMPHR_MUTEX_PATH,1); 

    // Aloca o buffer
    init_buffer(&shared_buffer, BUFFER_PATH, sizeof(SharedBuffer));

    
    int i = 0;
    for (;;)
    {
       i = i + 1;
       sem_wait(sem_empty);
       sem_wait(mutex);
       shared_buffer->value = i; //RC 1

       sprintf(shared_buffer->msg, "Produtor: %d\n",getpid());

       sem_post(mutex);
       sem_post(sem_full);

       if (i>=20)
       {
         sem_wait(sem_empty);
         sem_wait(mutex);
         shared_buffer->value = -1;  //RC 2
         sem_post(mutex);
         sem_post(sem_full);
         break;
       } 
       
       
    }
    
    /* Desaloca recursos */
      shm_unlink(BUFFER_PATH);
      sem_unlink("/sem_empty");
      sem_unlink("/sem_full");
      sem_unlink("/sem_mutex");
      sem_close(sem_empty);
      sem_close(sem_full);
      sem_close(mutex);
    return 0;
}
