#ifndef _SHARED_H_
#define _SHARED_H_

/* Includes */
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <semaphore.h> 
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/resource.h>
#include <sys/mman.h>
#include <sys/stat.h>


/* Definições do buffer */
#define BUFFER_PATH           "/my_buffer"
#define BUFFER_PERMISSIONS    S_IRUSR | S_IWUSR
#define BUFFER_FLAGS          O_CREAT | O_RDWR

/* Definições do semáforo */
#define SEMPHR_EMPTY_PATH "/sem_empty"
#define SEMPHR_FULL_PATH  "/sem_full" 
#define SEMPHR_MUTEX_PATH "/sem_mutex" 

#define SEM_PERMISSIONS S_IRUSR | S_IWUSR
#define SEM_FLAGS O_CREAT


/* Estruturas definidas */

typedef struct _SHARED_BUFFER_
{
  int value;
  char msg[40];
  
}SharedBuffer;


/* Protótipos da funções externas */

extern int init_semaforo(sem_t **s, const char* path, int value);
extern int init_buffer(void **buffer, const char* path, size_t tamanho);


#endif
