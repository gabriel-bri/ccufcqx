#include "shared.h"




int init_semaforo(sem_t **s, const char* path, int value)
{
  *s = sem_open(path, SEM_FLAGS, SEM_PERMISSIONS, value);

    if (*s == SEM_FAILED)
    {
       printf("Erro ao criar semáforo: %s\n",strerror(errno));
       return -1;
    }

    return 0;
}

int init_buffer(void **buffer, const char* path, size_t tamanho)
{

  //Criar o acesso a memória compartilhada
  int fd = shm_open(path, BUFFER_FLAGS, BUFFER_PERMISSIONS);


  if (fd == -1)
  {
     printf("Erro ao criar descritor do buffer: %s\n",strerror(errno));
     return -1;
  }

  //Ajusta o tamanho da memória compartilhada de acordo com a estrutura criada
  if (ftruncate(fd, tamanho) == -1)
  {
     printf("Erro ao ajustar tamanho do buffer: %s\n",strerror(errno));
     return -1;
  }

  /* Mapeia buffer para a variável my_buffer*/
  *buffer = mmap(NULL, tamanho, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
     
  if (*buffer == MAP_FAILED)
  {
    printf("Erro ao mapear buffer: %s\n",strerror(errno));
    return -1;
  }

  return 0;
}
