#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <sys/dir.h>

int main() {
    char str1[1024], str2[1024];
    
    FILE *fh1, *fh2, *fh3, *fh4;
    fh1 = fopen("arq1.txt", "r");
    fh2 = fopen("arq2.txt", "r");
    fh3 = fopen("temp.txt", "w");
    fh4 = fopen("diff.txt", "w");

    for(int offset = 0; (!feof(fh1)) && (!feof(fh2)); offset++){

        strcpy(str1," ");
	strcpy(str2," ");

        if(!feof(fh1)) fgets(str1,sizeof(str1),fh1);
        if(!feof(fh2)) fgets(str2,sizeof(str1),fh2);
		
        if(strcmp(str1,str2) == 0) { 
            fprintf(fh3,"%s", str1);
	}

        else {
	    fprintf(fh3,"%s", str1);
            fprintf(fh3,"%s", str2);
	}
    }
    fclose(fh1);
    fclose(fh2);
    fclose(fh3);
    fclose(fh4);
    
    system("awk 'NF>0' temp.txt >> diff.txt");

    return 0;
}
