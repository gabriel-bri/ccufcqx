 #include <stdio.h>
 #include <stdint.h>
 #include <stdlib.h>
 #include "wave.h"
 int main() {
    FILE *fp = NULL;
     //Referente a estrutura binária do arquivo.    
     Wav wav;
     RIFF_t riff;
     FMT_t fmt;
     Data_t data;
     
     //Procura abrir o arquivo em modo de leitura binária.
     fp = fopen("teste1.wav", "rb");

     if (!fp) {
         printf("Não foi possível abrir o arquivo de áudio.\n");
         exit(1);
     }
     //Faz a leitura do arquivo.
     fread(&wav, 1, sizeof(wav), fp);
     
     riff = wav.riff;
     fmt = wav.fmt;
     data = wav.data;

     //Exibe os dados do arquivo.
 
     printf("ID do pedaço: \t%c%c%c%c\n", riff.ChunkID[0], riff.ChunkID[1], riff.ChunkID[2], riff.ChunkID[3]);
     printf("Tamanho do pedaço: \t%d\n", riff.ChunkSize);
     printf("Formato: \t\t%c%c%c%c\n", riff.Format[0], riff.Format[1], riff.Format[2], riff.Format[3]);
     
     printf("\n");
     
     printf("ID do sub pedaço 1: \t%c%c%c%c\n", fmt.Subchunk1ID[0], fmt.Subchunk1ID[1], fmt.Subchunk1ID[2], fmt.Subchunk1ID[3]);
     printf("Tamanho do sub pedaço 1: \t%d\n", fmt.Subchunk1Size);
     printf("Formato do áudio: \t%d\n", fmt.AudioFormat);
     printf("Número de canais: \t%d\n", fmt.NumChannels);
     printf("Taxa de amostragem: \t%d\n", fmt.SampleRate);
     printf("Taxa de bytes: \t%d\n", fmt.ByteRate);
     printf("BlockAlign: \t%d\n", fmt.BlockAlign);
     printf("Bits por amostra: \t%d\n", fmt.BitsPerSample);
     
     printf("\n");
 
     printf("ID do bloco: \t%c%c%c%c\n", data.Subchunk2ID[0], data.Subchunk2ID[1], data.Subchunk2ID[2], data.Subchunk2ID[3]);
     printf("Tamanho do bloco: \t%d\n", data.Subchunk2Size);
     
     printf("\n");
    
     printf("Duração: \t%d\n", data.Subchunk2Size / fmt.ByteRate);
 }
