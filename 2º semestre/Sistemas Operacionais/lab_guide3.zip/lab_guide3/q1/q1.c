#include <dirent.h> 
#include <stdio.h> 
#include <unistd.h>
#include <stdlib.h>

int main(void) {
  //Pega o nome do usuário atual e imprime.
  char* username = getenv("USER");
  printf("Olá, você está logado como: @%s\n", username);

  DIR *d;
  struct dirent *dir;
  //Abre o diretório atual.
  d = opendir(".");
  
  //Pega o caminho do diretório atual.
  char cwd[1024];
  getcwd(cwd, sizeof(cwd));

  //Se conseguir abrir o diretório, ele encaminha para o próximo comand.
  if (d) {
    //Verifica enquanto a função readdir for diferente de nulo.
    while ((dir = readdir(d)) != NULL) {
        //Imprime o caminho e o nome dos seus arquivos na pasta
        if (dir->d_type == DT_REG){
     		printf("%s/%s\n", cwd, dir->d_name);
  	}
    }
    //Fecha o diretório.
    closedir(d);
  }

  else {
  	printf("Não foi possível abrir o diretório\n");
  }

  return(0);
}

