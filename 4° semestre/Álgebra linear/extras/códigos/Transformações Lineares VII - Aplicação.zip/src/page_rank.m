clear all;
close all;

% matriz de transicao para o grafo apresentado
M = [0 0 1 1/2 ; 1/3 0 0 0 ; 1/3 1/2 0 1/2 ; 1/3 1/2 0 0];

% estado inicial (probabilidade de o usuario estar na pagina)
r_0 = [1/4 ; 1/4 ; 1/4 ; 1/4];

% diagonalizacao da matriz de transicao
[P, D] = eig(M);

% autovetor correspondente ao autovalor dominante (lambda=1)
v = P(:,1);

% normalização do autovetor (soma de probabilidades igual a 1)
v = v./sum(v);

% matriz diagonalizada apos infinitas iteracoes (cliques)
D_inf = diag([1 0 0 0]);

% probabilidades (valor) de cada pagina apos infinitas iteracoes (convergencia)
r_inf = P*D_inf*inv(P)*r_0;

disp("Autovetor normalizado: ");
disp(v);

disp("Probabilidades das paginas: ");
disp(r_inf);