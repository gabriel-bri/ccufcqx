clear all;
close all;

A = [1 2 3 ; 2 3 -1 ; 3 2 1];
b = [2 ; -2 ; 2];

A_aug = [A b];

L = eye(3);

for i= 1:2
  l_i = A_aug(i,:);
  E = eye(3);
  for j = (i+1):3
    l_j = A_aug(j,:);
    l_j_new = l_j - (A_aug(j,i)/A_aug(i,i)).*l_i;
    E(j,i) = - (A_aug(j,i)/A_aug(i,i)); 
    A_aug(j,:) = l_j_new;
  endfor
  L = L * inv(E);
endfor

U = A_aug(:,1:3);