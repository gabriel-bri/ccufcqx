clear all;
close all;

A = [1 2 3 ; 2 3 -1 ; 3 2 1];
b = [2 ; -2 ; 2];

A_aug = [A b];

for i= 1:2
  l_i = A_aug(i,:);
  for j = (i+1):3
    l_j = A_aug(j,:);
    l_j_new = l_j - (A_aug(j,i)/A_aug(i,i)).*l_i;
    A_aug(j,:) = l_j_new;
  endfor
endfor