clear all;
close all;

%A = [1 2 3 ; 2 3 -1 ; 3 2 1];
A = [1 2 3 4 ; 2 3 -1 7 ; 3 2 1 2 ; 0 0 0 1];
n = 4

for i = 1:n
  for j = 1:n
    aux = A;
    aux(i,:) = [];
    aux(:,j) = [];    
    A_bar(i,j)=(-1)^(i+j)*det(aux);  
  endfor
endfor
    
A_inv = (1/det(A))*A_bar';